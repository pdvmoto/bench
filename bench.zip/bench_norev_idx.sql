alter INDEX EMP_DEPARTMENT_IX rebuild noreverse ;

alter INDEX EMP_EMAIL_UK rebuild noreverse ;

alter  INDEX EMP_EMP_ID_PK rebuild noreverse ;

alter INDEX EMP_JOB_IX rebuild noreverse ;

alter INDEX EMP_MANAGER_IX rebuild noreverse ;

alter INDEX EMP_NAME_IX rebuild noreverse ;

alter INDEX JHIST_DEPARTMENT_IX rebuild noreverse ;

alter INDEX JHIST_EMPLOYEE_IX rebuild noreverse ;

alter INDEX JHIST_EMP_ID_ST_DATE_PK rebuild noreverse ;

alter INDEX JHIST_JOB_IX rebuild noreverse ;


