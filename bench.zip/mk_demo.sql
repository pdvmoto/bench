

rem benchmark : 
rem based on : hd-demo from oracle 9i (easiest to implement)

/* 

considerations :
 - fill emp table up to 1M records, to simulate working on large table
 - when running benchmarks : use <10% records at a time, 
   effect of extra records in benchmark should be minimal.
 - when testing upd/del: make sure <10 % of table is deleted, 
   or alwas delete a given percentage (e.g. comparabe nr of errors per test)
 - beware : repeated updates will fill job-history table.
 - effect of commit-size will vary over db, depending on memory and RBS.

 - use these procs simultaneously, simulate n users hitting table

todo:
 - create how-to list to do quick benchmark in single user
 - idem to determine optimal commit-size.
 - idem for 5 or 10 users hitting db.
 - idem for a RAC database

 - find out what other errors occur, log them or ouput them.
 - report total contenst of emp + job_history
 - consider disabling trigger for job-history.

 - add to stdout of procs (on startup) :
	- global-name and schemaname
	- nr recs in emp and jobhist.
	- min/max of emp-id and curval of counter.

*/

rem insert : new employee:

rem need to alter emp_id and mgr_id to conain >6 digits
alter table employees  modify ( employee_id number (12,0) );
alter table employees  modify ( manager_id  number (12,0) );

rem emp_id : from seq.

rem find random job_id from jobs-lookup table :
rem - determine nr of numrows
rem - find random nr between 1 and numrows
rem - use select max(id) from ( order by, limit by random nr)

rem just to test/demo : show how to find a random job..
select max ( job_id) 
from (select job_id 
	from jobs 
	where rownum <= dbms_random.value ( 
			  1 
			, ( select count (*) from jobs )
                        )
	order by job_id 
     )
/


rem find valid dept. by selecting randomb value (see jobs)
rem find valid mgr : take mgr of dept : random from dept.mgr


rem try adding n employees

create or replace procedure ins_emp ( 
    pi_n_nr_emps         number default 1  -- default : 1 emp.
  , pi_n_commitsize      number default 1  -- default : commit every rec.
  ) 
as

-- 
-- insert n employees, commit after batch or after every record.
--

  n_nr_emps         number := pi_n_nr_emps ;       -- assign input-parameters
  n_commitsize      number := pi_n_commitsize ;

  i	            number := 0 ;  -- loopcounter
  n_current_commit  number := 0 ;  -- nr inserted in current commit. 

  n_nw_emp_id       employees.employee_id%type ;
  vc_nw_job_id      jobs.job_id%type ;
  n_nw_mgr_id       employees.employee_id%type ;
  n_nw_dept_id      departments.department_id%type ;

  d_start           date ;
  n_duration        number := 0 ;   -- sysdate - start, unit = sec!

  n_jobcount        number := 0 ;   -- workaround for v 8.x, 
  n_mgrcount        number := 0 ;   -- no inline select in dbms_random.
  n_deptcount       number := 0 ;
  
begin
  
  -- initialize some counters, only once, outside loop.
  select count (*) 
  into n_jobcount
  from jobs;

  select count (*) 
  into n_mgrcount
  from departments 
  where manager_id is not null ;

  select count (*) 
  into n_deptcount
  from departments;

  d_start := sysdate ;

  for i in 1..n_nr_emps loop

    -- assign new values : id, job, mgr, dept
    -- selecting these will simulate in-cache lookup-table usage

    select employees_seq.nextval 
    into n_nw_emp_id 
    from dual;

    select max ( job_id) 
    into vc_nw_job_id
    from ( select job_id 
           from jobs 
           where rownum <= dbms_random.value ( 1 , n_jobcount )
           order by 1
         );

    select max ( manager_id) 
    into n_nw_mgr_id
    from ( select manager_id 
           from departments 
           where rownum <= dbms_random.value ( 1, n_mgrcount )
           order by 1
         );

    select max ( department_id) 
    into n_nw_dept_id
    from ( select department_id 
           from departments 
           where rownum <= dbms_random.value ( 1, n_deptcount )
           order by 1
         );


    -- insert into table

    INSERT INTO EMPLOYEES (
	   EMPLOYEE_ID
	, FIRST_NAME
	, LAST_NAME
	, EMAIL
	, PHONE_NUMBER
	, HIRE_DATE
	, JOB_ID
	, SALARY
	, COMMISSION_PCT
	, MANAGER_ID
	, DEPARTMENT_ID ) 
	VALUES (
	  n_nw_emp_id
	, 'First_'  || to_char ( n_nw_emp_id )
	, 'Last_'   || to_char ( n_nw_emp_id )
	, 'MAIL_'   || to_char ( n_nw_emp_id ) || '@' 
          || 'dpt_' || to_char( n_nw_dept_id ) || '.com'
	, '+31 (' || to_char (n_nw_dept_id) || ') ' || to_char ( n_nw_emp_id )
	, trunc ( sysdate ) 
	, vc_nw_job_id
	, 3000
	, 0
	, n_nw_mgr_id
	, n_nw_dept_id
	);

	n_current_commit := n_current_commit + 1 ;

	if n_current_commit >= n_commitsize then
	  commit ;
	  n_current_commit := 0;
	  --dbms_output.put_line ( 'p_ins_emp : Committed at record: '  || to_char (i) ) ;
	end if ;

   end loop;

   commit ;  -- final commit, always.
   n_duration := trunc ( ( sysdate - d_start ) * 24 * 60 * 60 );
   if n_duration < 1 then
	n_duration  := 1;
   end if ;

   dbms_output.put_line (  'p_ins_emp : total inserted: '  || to_char (n_nr_emps) ) ;
   dbms_output.put_line (  'p_ins_emp : duraton : '  
			|| to_char ( n_duration ) || ' Sec.' 
			|| to_char ( n_nr_emps / n_duration, '999,999.99' ) 
			|| ' recs/sec' 
			) ;

   -- any exceptions go here...

end; -- ins_emp
/


show errors

create or replace procedure del_emp ( 
    pi_n_nr_emps         number default 1  -- default : 1 emp.
  , pi_n_commitsize      number default 1  -- default : commit every rec.
  ) 
as

-- 
-- delete n employees, commit after batch or after every record.
-- if emp cannot deleted : count as error.
--

  n_nr_emps         number := pi_n_nr_emps ;       -- assign input-parameters
  n_commitsize      number := pi_n_commitsize ;

  i	            number := 0 ;  -- loopcounter
  n_current_commit  number := 0 ;  -- nr inserted in current commit. 

  n_nw_emp_id       employees.employee_id%type ;
  vc_nw_job_id      jobs.job_id%type ;
  n_nw_mgr_id       employees.employee_id%type ;
  n_nw_dept_id      departments.department_id%type ;

			-- need min and max for random function.
  n_min_emp_id       employees.employee_id%type ;
  n_max_emp_id       employees.employee_id%type ;
  n_id_to_del        employees.employee_id%type ;

  n_deleted         number := 0;  -- count deleted
  n_errors          number := 0;  -- count errors
  n_not_found       number := 0;

  d_start           date ;
  n_duration        number := 0 ;   -- sysdate - start, unit = sec!

  
begin

  -- determine outer limits for min/max.
  select min (employee_id), max (employee_id)
  into n_min_emp_id, n_max_emp_id
  from employees;
  
  d_start := sysdate ;

  for i in 1..n_nr_emps loop


    -- just try to delete one at random, need separate block.
    begin 

      select employee_id 
      into n_id_to_del
      from employees
      where employee_id = trunc ( dbms_random.value ( n_min_emp_id, n_max_emp_id ) )
      for update nowait ;

      delete from employees
      where employee_id = n_id_to_del;

      n_deleted        := n_deleted        + 1;
      n_current_commit := n_current_commit + 1 ;

    exception 
    when no_data_found then
      n_not_found  := n_not_found + 1 ;
    when others then
      n_errors     := n_errors + 1;
    end;

    if n_current_commit >= n_commitsize then
      commit ;
      n_current_commit := 0;
      --dbms_output.put_line ( 'p_del_emp : Committed at record: '  || to_char (i) ) ;
    end if ;

  end loop;

  commit ;  -- final commit, always.

   n_duration := trunc ( ( sysdate - d_start ) * 24 * 60 * 60 );
   if n_duration < 1 then
	n_duration  := 1;
   end if ;

   dbms_output.put_line (  'p_del_emp : deleted/tried : '  
			|| to_char (n_deleted) || ' / ' || to_char (n_nr_emps) 
			) ;
   dbms_output.put_line (  'p_del_emp : not_found           : '  
			|| to_char (n_not_found)  
			) ;
   dbms_output.put_line (  'p_del_emp : nr of errors        : '  
			|| to_char (n_errors)  
			) ;
   dbms_output.put_line (  'p_del_emp : duraton : '  
			|| to_char ( n_duration ) || ' Sec '
			|| to_char ( n_nr_emps / n_duration, '999,999.99' ) 
			|| ' recs/sec' 
			) ;

   -- any exceptions go here...

end; -- del_emp
/

show errors

create or replace procedure del_emp_dbg ( 
    pi_n_nr_emps         number default 1  -- default : 1 emp.
  , pi_n_commitsize      number default 1  -- default : commit every rec.
  , pi_n_dbg             number default 0  -- <> 0 means do debugging
  ) 
as

-- 
-- delete n employees, commit after batch or after every record.
-- if emp cannot deleted : count as error.
--

  n_nr_emps         number := pi_n_nr_emps ;       -- assign input-parameters
  n_commitsize      number := pi_n_commitsize ;

  i	            number := 0 ;  -- loopcounter
  n_current_commit  number := 0 ;  -- nr inserted in current commit. 

  n_nw_emp_id       employees.employee_id%type ;
  vc_nw_job_id      jobs.job_id%type ;
  n_nw_mgr_id       employees.employee_id%type ;
  n_nw_dept_id      departments.department_id%type ;

			-- need min and max for random function.
  n_min_emp_id       employees.employee_id%type ;
  n_max_emp_id       employees.employee_id%type ;
  n_id_to_del        employees.employee_id%type ;

  n_deleted         number := 0;  -- count deleted
  n_errors          number := 0;  -- count errors
  n_not_found       number := 0;

  d_start           date ;
  n_duration        number := 0 ;   -- sysdate - start, unit = sec!

  
begin

  -- determine outer limits for min/max.
  select min (employee_id), max (employee_id)
  into n_min_emp_id, n_max_emp_id
  from employees;
  
  d_start := sysdate ;

  for i in 1..n_nr_emps loop


    -- just try to delete one at random, need separate block.
    begin 

      select employee_id 
      into n_id_to_del
      from employees
      where employee_id = trunc ( dbms_random.value ( n_min_emp_id, n_max_emp_id ) )
      for update nowait ;

      delete from employees
      where employee_id = n_id_to_del;

      n_deleted        := n_deleted        + 1;
      n_current_commit := n_current_commit + 1 ;

    exception 
    when no_data_found then
      n_not_found  := n_not_found + 1 ;
    when others then
      n_errors     := n_errors + 1;
      if pi_n_dbg <> 0 then
        dbms_output.put_line ( 'p_del_emp : error : ['  || SQLERRM || ']' ) ;
      end if;
    end;

    if n_current_commit >= n_commitsize then
      commit ;
      n_current_commit := 0;
      --dbms_output.put_line ( 'p_del_emp : Committed at record: '  || to_char (i) ) ;
    end if ;

  end loop;

  commit ;  -- final commit, always.

   n_duration := trunc ( ( sysdate - d_start ) * 24 * 60 * 60 );
   if n_duration < 1 then
	n_duration  := 1;
   end if ;

   dbms_output.put_line (  'p_del_emp : deleted/tried : '  
			|| to_char (n_deleted) || ' / ' || to_char (n_nr_emps) 
			) ;
   dbms_output.put_line (  'p_del_emp : not_found           : '  
			|| to_char (n_not_found)  
			) ;
   dbms_output.put_line (  'p_del_emp : nr of errors        : '  
			|| to_char (n_errors)  
			) ;
   dbms_output.put_line (  'p_del_emp : duraton : '  
			|| to_char ( n_duration ) || ' Sec '
			|| to_char ( n_nr_emps / n_duration, '999,999.99' ) 
			|| ' recs/sec' 
			) ;

   -- any exceptions go here...

end; -- del_emp_dbg
/

show errors



create or replace procedure upd_emp_dbg ( 
    pi_n_nr_emps         number default 1  -- default : 1 emp.
  , pi_n_commitsize      number default 1  -- default : commit every rec.
  , pi_n_dbg             number default 0  -- <> 0 means do debugging
  ) 
as

-- 
-- update n employees, commit after batch or after every record.
-- if emp cannot be updated (why?) : count as error.
--

  n_nr_emps         number := pi_n_nr_emps ;       -- assign input-parameters
  n_commitsize      number := pi_n_commitsize ;

  i	            number := 0 ;  -- loopcounter
  n_current_commit  number := 0 ;  -- nr inserted in current commit. 

  n_nw_emp_id       employees.employee_id%type ;
  vc_nw_job_id      jobs.job_id%type ;
  n_nw_mgr_id       employees.employee_id%type ;
  n_nw_dept_id      departments.department_id%type ;

			-- need min and max for random function.
  n_min_emp_id       employees.employee_id%type ;
  n_max_emp_id       employees.employee_id%type ;
  n_id_to_upd        employees.employee_id%type ;

  n_updated         number := 0;  -- count deleted
  n_errors          number := 0;  -- count errors
  n_not_found       number := 0;

  d_start           date ;
  n_duration        number := 0 ;   -- sysdate - start, unit = sec!

  n_jobcount        number := 0 ;   -- workaround for v 8.x, 
  n_mgrcount        number := 0 ;   -- no inline select in dbms_random.
  n_deptcount       number := 0 ;
  
  
begin

  -- initialize some counters, only once, outside loop.
  select count (*) 
  into n_jobcount
  from jobs;

  select count (*) 
  into n_mgrcount
  from departments 
  where manager_id is not null ;

  select count (*) 
  into n_deptcount
  from departments;

  -- determine outer limits for min/max.
  select min (employee_id), max (employee_id)
  into n_min_emp_id, n_max_emp_id
  from employees;
  
  d_start := sysdate ;

  for i in 1..n_nr_emps loop

    -- assign new values : id, job, mgr, dept
    -- selecting these will simulate in-cache lookup-table usage

    select max ( job_id) 
    into   vc_nw_job_id
    from ( select job_id 
	   from jobs 
	   where rownum <= dbms_random.value ( 1, n_jobcount )
	   order by 1
         ) ;

    select max ( manager_id) 
    into n_nw_mgr_id
    from (select manager_id 
	from departments 
	where rownum <= dbms_random.value ( 1, n_mgrcount )
        and manager_id is not null
	order by 1
     );

    select max ( department_id) 
    into n_nw_dept_id
    from (select department_id 
	from departments 
	where rownum <= dbms_random.value ( 1, n_deptcount )
	order by 1
     );


    -- just try to update one at random, need separate block for exceptions.
    begin 

      select employee_id 
      into n_id_to_upd
      from employees
      where employee_id = trunc ( dbms_random.value ( n_min_emp_id, n_max_emp_id ) )
      for update nowait ;

      update employees
	set job_id        = vc_nw_job_id
          , manager_id    = n_nw_mgr_id
          , department_id = n_nw_dept_id
          , hire_date     = sysdate
      where employee_id = n_id_to_upd;

      n_updated        := n_updated        + 1;
      n_current_commit := n_current_commit + 1 ;

    exception 
    when no_data_found then
      n_not_found  := n_not_found + 1 ;
    when others then
      n_errors     := n_errors + 1;
      if pi_n_dbg <> 0 then
        dbms_output.put_line ( 'p_upd_emp : error : ['  || substr ( SQLERRM, 1, 190) || ']' ) ;
      end if;
    end;

    if n_current_commit >= n_commitsize then
      commit ;
      n_current_commit := 0;
      --dbms_output.put_line ( 'p_upd_emp : Committed at record: '  || to_char (i) ) ;
    end if ;

  end loop;

  commit ;  -- final commit, always.

   n_duration := trunc ( ( sysdate - d_start ) * 24 * 60 * 60 );
   if n_duration < 1 then
	n_duration  := 1;
   end if ;

   dbms_output.put_line (  'p_upd_emp : updated/tried : '  
			|| to_char (n_updated) || ' / ' || to_char (n_nr_emps) 
			) ;
   dbms_output.put_line (  'p_upd_emp : not_found           : '  
			|| to_char (n_not_found)  
			) ;
   dbms_output.put_line (  'p_upd_emp : nr of errors        : '  
			|| to_char (n_errors)  
			) ;
   dbms_output.put_line (  'p_upd_emp : duraton : '  
			|| to_char ( n_duration ) || ' Sec.' 
			|| to_char ( n_nr_emps / n_duration, '999,999.99' ) 
			|| ' recs/sec' 
			) ;

   -- any exceptions go here...

end; -- upd_emp
/

show errors


create or replace procedure upd_emp ( 
    pi_n_nr_emps         number default 1  -- default : 1 emp.
  , pi_n_commitsize      number default 1  -- default : commit every rec.
  ) 
as

-- 
-- update n employees, commit after batch or after every record.
-- if emp cannot be updated (why?) : count as error.
--

  n_nr_emps         number := pi_n_nr_emps ;       -- assign input-parameters
  n_commitsize      number := pi_n_commitsize ;

  i	            number := 0 ;  -- loopcounter
  n_current_commit  number := 0 ;  -- nr inserted in current commit. 

  n_nw_emp_id       employees.employee_id%type ;
  vc_nw_job_id      jobs.job_id%type ;
  n_nw_mgr_id       employees.employee_id%type ;
  n_nw_dept_id      departments.department_id%type ;

			-- need min and max for random function.
  n_min_emp_id       employees.employee_id%type ;
  n_max_emp_id       employees.employee_id%type ;
  n_id_to_upd        employees.employee_id%type ;

  n_updated         number := 0;  -- count deleted
  n_errors          number := 0;  -- count errors
  n_not_found       number := 0;

  d_start           date ;
  n_duration        number := 0 ;   -- sysdate - start, unit = sec!

  n_jobcount        number := 0 ;   -- workaround for v 8.x, 
  n_mgrcount        number := 0 ;   -- no inline select in dbms_random.
  n_deptcount       number := 0 ;
  
  
begin

  -- initialize some counters, only once, outside loop.
  select count (*) 
  into n_jobcount
  from jobs;

  select count (*) 
  into n_mgrcount
  from departments 
  where manager_id is not null ;

  select count (*) 
  into n_deptcount
  from departments;

  -- determine outer limits for min/max.
  select min (employee_id), max (employee_id)
  into n_min_emp_id, n_max_emp_id
  from employees;
  
  d_start := sysdate ;

  for i in 1..n_nr_emps loop

    -- assign new values : id, job, mgr, dept
    -- selecting these will simulate in-cache lookup-table usage

    select max ( job_id) 
    into   vc_nw_job_id
    from ( select job_id 
	   from jobs 
	   where rownum <= dbms_random.value ( 1, n_jobcount )
	   order by 1
         ) ;

    select max ( manager_id) 
    into n_nw_mgr_id
    from (select manager_id 
	from departments 
	where rownum <= dbms_random.value ( 1, n_mgrcount )
        and manager_id is not null
	order by 1
     );

    select max ( department_id) 
    into n_nw_dept_id
    from (select department_id 
	from departments 
	where rownum <= dbms_random.value ( 1, n_deptcount )
	order by 1
     );


    -- just try to update one at random, need separate block for exceptions.
    begin 

      select employee_id 
      into n_id_to_upd
      from employees
      where employee_id = trunc ( dbms_random.value ( n_min_emp_id, n_max_emp_id ) )
      for update nowait ;

      update employees
	set job_id        = vc_nw_job_id
          , manager_id    = n_nw_mgr_id
          , department_id = n_nw_dept_id
      where employee_id = n_id_to_upd;

      n_updated        := n_updated        + 1;
      n_current_commit := n_current_commit + 1 ;

    exception 
    when no_data_found then
      n_not_found  := n_not_found + 1 ;
    when others then
      n_errors     := n_errors + 1;
    end;

    if n_current_commit >= n_commitsize then
      commit ;
      n_current_commit := 0;
      --dbms_output.put_line ( 'p_upd_emp : Committed at record: '  || to_char (i) ) ;
    end if ;

  end loop;

  commit ;  -- final commit, always.

   n_duration := trunc ( ( sysdate - d_start ) * 24 * 60 * 60 );
   if n_duration < 1 then
	n_duration  := 1;
   end if ;

   dbms_output.put_line (  'p_upd_emp : updated/tried : '  
			|| to_char (n_updated) || ' / ' || to_char (n_nr_emps) 
			) ;
   dbms_output.put_line (  'p_upd_emp : not_found           : '  
			|| to_char (n_not_found)  
			) ;
   dbms_output.put_line (  'p_upd_emp : nr of errors        : '  
			|| to_char (n_errors)  
			) ;
   dbms_output.put_line (  'p_upd_emp : duraton : '  
			|| to_char ( n_duration ) || ' Sec.' 
			|| to_char ( n_nr_emps / n_duration, '999,999.99' ) 
			|| ' recs/sec' 
			) ;

   -- any exceptions go here...

end; -- upd_emp_dbg
/

show errors


-- call just once, to test.

@count employees

set serveroutput on

exec ins_emp    ( 1, 1     ) ;

@count employees

exec del_emp     ( 1, 7    ) ;

exec del_emp_dbg ( 1, 2, 1 ) ;

@count employees

exec upd_emp     ( 1, 7    ) ;

exec upd_emp_dbg ( 1, 7, 1 ) ;

@count employees

